# This is a simple example web app that is meant to illustrate the basics.
from flask import Flask, render_template, redirect, g, request, url_for
import sqlite3
import requests
import urllib
import os


DATABASE = 'todolist.db'
API_URL = "http://10.229.8.133:5001/"
# API_URL = "http://"+os.environ['TODO_API']+":5001/"



app = Flask(__name__)
app.config.from_object(__name__)



# landing page
@app.route("/")
def show_homepage():
    return render_template('register.html')
    

# homepage
@app.route("/todo", methods=['GET','POST'])
def show_list():
    todo = requests.get(API_URL+"/api/items")
    todo = todo.json()
    return render_template('homepage.html',tdlist=todo)
    

# register page
@app.route("/register", methods=['POST'])
def register():
    resp = requests.post(API_URL+'api/register', json={
                  "full_name": request.form['full_name'], "email": request.form['email'],"phone":request.form['phone'],"password":request.form['password']})
    print(resp)
    resp = resp.json()
    print(resp)
    if resp['result']:
        return render_template('login.html')
    else:
        return render_template('register.html')

# login page
@app.route("/login", methods=['POST'])
def login():
    resp = requests.post(API_URL+'api/login', json={
                   "email": request.form['email'],"password":request.form['password']})
    todo = requests.get(API_URL+"/api/items")
    todo = todo.json()
    print(resp)
    print(request.form['email'],request.form['password'])
    resp = resp.json()
    print('from todo', resp)
    if resp['result']:
        return redirect(url_for('show_list'))
    else:
        return render_template('login_retry.html')

@app.route("/add", methods=['POST'])
def add_todo():
    resp = requests.post(API_URL+'add', json={
                  "what_to_do": request.form['what_to_do'], "due_date": request.form['due_date']})
    print(resp)
    resp = resp.json()
    print(resp)
    if resp['result']:
        return redirect(url_for('show_list'))
    else:
        return render_template('login.html')

# delete 
@app.route("/delete/<item>")
def delete_entry(item):
    item = urllib.parse.quote(item)
    requests.delete(API_URL+"delete/"+item)
    return redirect(url_for('show_list'))

# update
@app.route("/mark/<item>")
def mark_as_done(item):
    item = urllib.parse.quote(item)
    requests.put(API_URL+"api/items/"+item)
    return redirect(url_for('show_list'))

def get_db():
    """Opens a new database connection if there is none yet for the
    current application context.
    """
    if not hasattr(g, 'sqlite_db'):
        g.sqlite_db = sqlite3.connect(app.config['DATABASE'])
    return g.sqlite_db


@app.teardown_appcontext
def close_db(error):
    """Closes the database again at the end of the request."""
    if hasattr(g, 'sqlite_db'):
        g.sqlite_db.close()


if __name__ == "__main__":
    app.run("0.0.0.0",port=80)
