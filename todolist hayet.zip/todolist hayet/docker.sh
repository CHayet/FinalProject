gcloud compute ssh finalproject --zone=us-central1-a --command='
sudo apt install python3-pip
sudo apt-get install wget
sudo pip3 install flask
sudo pip3 install requests
sudo pip3 install urllib3
sudo apt-get install unzip
wget -nc https://raw.githubusercontent.com/dougymenns/cisc5550/main/todolistgit.zip
sudo unzip todolistgit.zip 
cd todolistgit
sudo chmod 777 /home/dougymenns/todolistgit
python3 todolist_api.py
'

export TODO_API=`gcloud compute instances list --filter="name=hw3" --format="value(EXTERNAL_IP)"`

docker build -t cisc-final:v1 --build-arg api_ip=${TODO_API} . 

docker tag cisc-final:v1 gcr.io/cisc5550gcloud/cisc-fiinal:v1 
docker push gcr.io/cisc5550gcloud/cisc-final:v1 

gcloud container clusters create final --zone=us-central1-a
kubectl create deployment final --image=gcr.io/cisc5550gcloud/cisc-final:v1 
kubectl expose deployment final --type=LoadBalancer --port=80 --target-port=80
sleep 1m
kubectl get services